# KIRMA Automation Intelligence

MVP de KIRMA-SOFT: diagnóstico preliminar y explicable del potencial de
automatización de un proceso de negocio.

## Qué hay en este entregable

```
/README.md
/app.html                        ← app publicada (landing, formulario, motor, resultado, dashboard)
/src/domain/kirma-engine/         ← Motor KIRMA V1, módulo puro sin UI
/tests/engine.test.js             ← suite de pruebas (casos A–G + reglas transversales)
/supabase/                        ← schema, políticas RLS y Edge Function de referencia para producción
/docs/                             ← ARCHITECTURE, ENGINE, AI, SECURITY, TESTING, DEPLOYMENT
```

## Estado real de este entregable (léase antes de todo)

Esto se construyó en un entorno de conversación con Claude, no en un
repositorio con despliegue propio. Eso da dos entregables distintos:

1. **Una app funcional de verdad, publicada y usable hoy** (`app.html`),
   que corre el flujo completo — landing → formulario de 10 pasos → Motor
   KIRMA V1 → IA opcional con fallback → resultado tipo informe →
   consentimiento/lead → dashboard con KPIs, filtros, cambio de estado e
   historial — usando el almacenamiento (`db`), la capa de IA (`sample`)
   y las descargas (`downloads`) que ofrece el propio artefacto como
   sustituto de Supabase/Edge Functions mientras no hay backend propio.
2. **Los artefactos de referencia para llevarlo a producción real**
   (`/supabase`, `/docs/SECURITY.md`, `/docs/DEPLOYMENT.md`): schema SQL,
   políticas RLS con roles admin/sales/viewer, y una Edge Function de
   ejemplo para mover la llamada de IA a un backend con la API key oculta.
   Esto no está desplegado — requiere que ustedes creen el proyecto
   Supabase y lo desplieguen.

La limitación concreta: en el prototipo publicado, el control de "quién
puede cambiar el estado de un diagnóstico" es un interruptor de interfaz
("Portal cliente" / "Equipo KIRMA"), **no** una barrera de seguridad real.
Cualquiera con el enlace de la app puede alternarlo. La sección 24 del
prompt original exige que solo `admin`/`sales` puedan modificar estados;
eso solo puede aplicarse con autenticación y RLS real, que es exactamente
lo que `/supabase` deja listo para desplegar.

## Motor KIRMA V1

Vive en `/src/domain/kirma-engine/engine.js`, sin dependencias de UI ni
red, testeado en `/tests/engine.test.js` (13/13 pruebas verdes, incluyendo
los 7 casos obligatorios A–G de la sección 32 del prompt maestro). El
mismo código está también portado dentro de `app.html` (sección
`KirmaEngine`) para poder correr en el navegador sin bundler.

Ejecutar pruebas:

```bash
node tests/engine.test.js
```

## Orden de implementación seguido

Fases 1–2 (motor + tests): completas y probadas.
Fase 3 (formulario + diagnóstico): completa, funcional en `app.html`.
Fase 4 (IA): completa como capa opcional con fallback (`sample` + Motor
determinista); ver `docs/AI.md`.
Fase 5 (persistencia): completa vía `db`, con schema equivalente listo
para Supabase en `/supabase`.
Fase 6 (leads): completo — diagnóstico y lead se persisten por separado,
el lead requiere consentimiento explícito.
Fase 7 (dashboard): completo — KPIs, filtros, estados, historial.
Fase 8 (seguridad): documentada y con RLS de referencia lista para
Supabase; **no aplicada de forma forzosa** en el prototipo (ver arriba).
Fase 9 (PDF): implementado como informe HTML descargable + impresión del
navegador ("Guardar como PDF"); un PDF con maquetación de marca fija
requeriría una librería de generación en servidor (ver `docs/DEPLOYMENT.md`).
Fase 10 (analítica): eventos definidos en `docs/ARCHITECTURE.md`, no
instrumentados en el prototipo (no hay backend de analítica disponible
aquí).
