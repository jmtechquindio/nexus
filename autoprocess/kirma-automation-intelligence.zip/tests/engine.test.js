const assert = require('assert');
const { runKirmaEngine } = require('../src/domain/kirma-engine/engine');

let passed = 0;
let failed = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`✅ ${name}`);
    passed++;
  } catch (err) {
    console.log(`❌ ${name}`);
    console.log(`   ${err.message}`);
    failed++;
  }
}

// ---------------------------------------------------------------------------
// A — Facturas → Alto potencial
// ---------------------------------------------------------------------------
test('A — Facturas por correo (alto volumen, estructurado) → high', () => {
  const result = runKirmaEngine({
    processDescription: 'Recibimos facturas por correo, descargamos los PDF, extraemos datos, validamos, registramos en Excel, cargamos al sistema y enviamos confirmación.',
    frequency: 'daily',
    volumeMonthly: 450,
    minutesPerOp: 8,
    structure: 'mostly',
    exceptions: 'sometimes',
    tools: ['email', 'pdf', 'excel', 'erp'],
    humanIntervention: '25-50',
    risk: 'low',
    complexity: 'medium',
    integration: 'api_available',
    people: 'several',
    sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'high', `esperado high, obtuvo ${result.technical_potential}`);
  assert.ok(result.stages.length > 0, 'debe detectar al menos una etapa');
});

// ---------------------------------------------------------------------------
// B — WhatsApp → Potencial parcial o evaluación técnica
// ---------------------------------------------------------------------------
test('B — Atención por WhatsApp (poco estructurado) → partial o technical', () => {
  const result = runKirmaEngine({
    processDescription: 'Los clientes escriben por WhatsApp con dudas variadas, un agente responde según el caso y a veces escala a otra área.',
    frequency: 'multiple_daily',
    volumeMonthly: 600,
    minutesPerOp: 5,
    structure: 'depends',
    exceptions: 'frequently',
    tools: ['whatsapp'],
    humanIntervention: '50-75',
    risk: 'medium',
    complexity: 'medium',
    integration: 'unknown',
    people: 'team',
    sensitivity: 'no',
  });
  assert.ok(['partial', 'technical'].includes(result.technical_potential), `esperado partial/technical, obtuvo ${result.technical_potential}`);
});

// ---------------------------------------------------------------------------
// C — Cartera / cobranza → Evaluación técnica
// ---------------------------------------------------------------------------
test('C — Gestión de cartera vencida (riesgo alto, negociación) → technical', () => {
  const result = runKirmaEngine({
    processDescription: 'Revisamos cartera vencida, negociamos condiciones de pago con cada cliente según su historial y decidimos si enviamos a cobro jurídico.',
    frequency: 'weekly',
    volumeMonthly: 90,
    minutesPerOp: 30,
    structure: 'depends',
    exceptions: 'frequently',
    tools: ['erp', 'documents'],
    humanIntervention: '50-75',
    risk: 'high',
    complexity: 'high',
    integration: 'unknown',
    people: 'several',
    sensitivity: 'yes',
  });
  assert.strictEqual(result.technical_potential, 'technical', `esperado technical, obtuvo ${result.technical_potential}`);
});

// ---------------------------------------------------------------------------
// D — Inventario → Alto potencial
// ---------------------------------------------------------------------------
test('D — Actualización de inventario (reglas claras, alto volumen) → high', () => {
  const result = runKirmaEngine({
    processDescription: 'Recibimos reportes de ventas del sistema, actualizamos el inventario, validamos existencias y registramos alertas de stock bajo.',
    frequency: 'daily',
    volumeMonthly: 800,
    minutesPerOp: 3,
    structure: 'always',
    exceptions: 'almost_never',
    tools: ['erp', 'database', 'api'],
    humanIntervention: '<25',
    risk: 'low',
    complexity: 'low',
    integration: 'api_available',
    people: 'one',
    sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'high', `esperado high, obtuvo ${result.technical_potential}`);
});

// ---------------------------------------------------------------------------
// E — Proceso crítico → Evaluación técnica
// ---------------------------------------------------------------------------
test('E — Aprobación de créditos grandes (riesgo crítico) → technical', () => {
  const result = runKirmaEngine({
    processDescription: 'Evaluamos y aprobamos solicitudes de crédito de alto monto, decidiendo condiciones caso por caso.',
    frequency: 'weekly',
    volumeMonthly: 20,
    minutesPerOp: 60,
    structure: 'depends',
    exceptions: 'frequently',
    tools: ['erp', 'documents'],
    humanIntervention: '50-75',
    risk: 'critical',
    complexity: 'high',
    integration: 'unknown',
    people: 'multiple_areas',
    sensitivity: 'yes',
  });
  assert.strictEqual(result.technical_potential, 'technical', `esperado technical, obtuvo ${result.technical_potential}`);
});

// ---------------------------------------------------------------------------
// F — Proceso ocasional y subjetivo → Bajo potencial actual
// ---------------------------------------------------------------------------
test('F — Diseño de campaña creativa ocasional (subjetivo) → low', () => {
  const result = runKirmaEngine({
    processDescription: 'De vez en cuando diseñamos una campaña creativa nueva según el criterio del equipo de marketing.',
    frequency: 'occasional',
    volumeMonthly: 2,
    minutesPerOp: 600,
    structure: 'always_different',
    exceptions: 'constantly',
    tools: ['custom_software'],
    humanIntervention: '>75',
    risk: 'low',
    complexity: 'high',
    integration: 'no_integration',
    people: 'team',
    sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'low', `esperado low, obtuvo ${result.technical_potential}`);
});

// ---------------------------------------------------------------------------
// G — Contradicciones → Evaluación técnica
// ---------------------------------------------------------------------------
test('G1 — Contradicción volumen alto + tiempo cero → technical + confidence low', () => {
  const result = runKirmaEngine({
    processDescription: 'Procesamos pedidos todos los días de forma manual.',
    frequency: 'daily',
    volumeMonthly: 500,
    minutesPerOp: 0,
    structure: 'mostly',
    exceptions: 'sometimes',
    tools: ['erp'],
    humanIntervention: '25-50',
    risk: 'low',
    complexity: 'low',
    integration: 'api_available',
    people: 'one',
    sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'technical');
  assert.strictEqual(result.confidence, 'low');
  assert.ok(result.contradictions.length > 0, 'debe detectar la contradicción de volumen/tiempo');
});

test('G2 — Contradicción estructura siempre igual + dependencia humana >75% → technical', () => {
  const result = runKirmaEngine({
    processDescription: 'El proceso siempre se hace exactamente de la misma manera, paso a paso.',
    frequency: 'daily',
    volumeMonthly: 200,
    minutesPerOp: 10,
    structure: 'always',
    exceptions: 'almost_never',
    tools: ['excel'],
    humanIntervention: '>75',
    risk: 'low',
    complexity: 'low',
    integration: 'no_integration',
    people: 'one',
    sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'technical');
  assert.ok(result.contradictions.some((c) => c.code === 'STRUCTURE_VS_HUMAN_DEPENDENCE'));
});

test('G3 — Contradicción riesgo crítico sin supervisión → technical', () => {
  const result = runKirmaEngine({
    processDescription: 'Autorizamos transferencias internacionales de montos altos.',
    frequency: 'weekly',
    volumeMonthly: 40,
    minutesPerOp: 15,
    structure: 'mostly',
    exceptions: 'sometimes',
    tools: ['erp'],
    humanIntervention: '<25',
    risk: 'critical',
    complexity: 'medium',
    integration: 'api_available',
    people: 'one',
    sensitivity: 'yes',
  });
  assert.strictEqual(result.technical_potential, 'technical');
  assert.ok(result.contradictions.some((c) => c.code === 'CRITICAL_RISK_NO_OVERSIGHT'));
});

// ---------------------------------------------------------------------------
// Reglas transversales adicionales
// ---------------------------------------------------------------------------

test('internal_score nunca se expone como porcentaje/ROI (solo campo numérico interno 0-1)', () => {
  const result = runKirmaEngine({ processDescription: 'x'.repeat(20), frequency: 'daily', volumeMonthly: 100, minutesPerOp: 5 });
  assert.ok(typeof result.internal_score === 'number');
  assert.ok(result.internal_score >= 0 && result.internal_score <= 1);
});

test('información insuficiente (muchos unknown) fuerza technical + confidence low', () => {
  const result = runKirmaEngine({ processDescription: 'Hacemos cosas variadas.' });
  assert.strictEqual(result.technical_potential, 'technical');
  assert.strictEqual(result.confidence, 'low');
  assert.ok(result.missing_information.length >= 5);
});

test('cálculo de horas: volumen × minutos / 60', () => {
  const result = runKirmaEngine({
    processDescription: 'Proceso de prueba con suficiente longitud de texto para no marcar falta de descripción.',
    frequency: 'daily', volumeMonthly: 120, minutesPerOp: 10, structure: 'mostly', exceptions: 'sometimes',
    tools: ['excel'], humanIntervention: '25-50', risk: 'low', complexity: 'low', integration: 'api_available',
    people: 'one', sensitivity: 'no',
  });
  assert.strictEqual(result.hours_estimated_monthly, 20);
});

test('el motor nunca dice "no se puede automatizar" (low ≠ imposibilidad)', () => {
  const result = runKirmaEngine({
    processDescription: 'Proceso ocasional muy subjetivo que depende totalmente del criterio individual del responsable.',
    frequency: 'occasional', volumeMonthly: 1, minutesPerOp: 300, structure: 'always_different',
    exceptions: 'constantly', tools: [], humanIntervention: '>75', risk: 'low', complexity: 'high',
    integration: 'no_integration', people: 'one', sensitivity: 'no',
  });
  assert.strictEqual(result.technical_potential, 'low');
  assert.ok(!result.recommendation.toLowerCase().includes('no se puede automatizar'));
});

// ---------------------------------------------------------------------------
console.log(`\n${passed} pasaron, ${failed} fallaron`);
process.exit(failed > 0 ? 1 : 0);
