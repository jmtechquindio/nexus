# DEPLOYMENT.md

## Lo que ya está desplegado

`app.html` está publicado como artefacto de Claude (enlace compartido en
la conversación). Corre completo — landing, formulario, motor, IA con
fallback, resultado, consentimiento/lead, dashboard — usando las
capacidades del propio artefacto (`db`, `sample`, `downloads`) como
almacenamiento y capa de IA. No requiere ningún despliegue adicional
para usarse tal cual.

## Cómo llevarlo a un dominio propio con Supabase (producción real)

### 1. Crear el proyecto Supabase

```bash
supabase init
supabase link --project-ref <tu-proyecto>
supabase db push   # aplica /supabase/migrations/0001_init.sql y 0002_rls.sql
```

### 2. Variables de entorno

En el proyecto Supabase (Edge Functions → Secrets):

```
AI_PROVIDER_API_KEY=...   # nunca en el frontend
```

En el frontend (build-time, público, sin secretos):

```
SUPABASE_URL=...
SUPABASE_ANON_KEY=...
```

### 3. Desplegar la Edge Function de IA

```bash
supabase functions deploy ai-diagnose
```

Sustituir en `app.html` la llamada a `claude.use('sample')` por un
`fetch` a `${SUPABASE_URL}/functions/v1/ai-diagnose` con el mismo
contrato (`{ processDescription } → { stages }`), manteniendo intacta la
regla de fallback: si `stages` viene `null`, seguir usando
`decomposeStagesHeuristic()` del Motor KIRMA V1.

### 4. Autenticación y roles

- Crear usuarios reales para el equipo (`admin`, `sales`, `viewer`) vía
  Supabase Auth.
- Insertar su fila correspondiente en `user_profiles` con el `role`
  correcto — sin esto, `current_kirma_role()` devuelve `null` y las
  políticas RLS de `UPDATE` los bloquean (comportamiento correcto por
  defecto: denegar si no hay rol asignado).
- Reemplazar el interruptor "Portal cliente / Equipo KIRMA" por una
  pantalla de login real; el dashboard solo debe renderizarse tras
  verificar sesión + rol.

### 5. Reemplazar el almacenamiento `db` por Supabase

- `S.db.collection('diagnostics')` → llamadas al cliente de Supabase
  (`supabase.from('diagnostics')`), respetando el mismo shape de campos
  ya usado en el prototipo (coincide 1:1 con `0001_init.sql`).
- El `INSERT` público desde el formulario debe pasar por una Edge
  Function o una función RPC con `security definer`, nunca por un
  `INSERT` directo del cliente anónimo con service role.

### 6. CAPTCHA / Turnstile

Agregar Cloudflare Turnstile (o reCAPTCHA) en el paso de contacto del
formulario (paso 10) y validar el token en la Edge Function antes de
insertar el diagnóstico — evita abuso del formulario público.

### 7. PDF de marca fija

El prototipo genera un informe HTML descargable e imprimible
(`window.print()` con estilos `@media print` ya definidos en `app.html`).
Para un PDF con maquetación de marca exacta generado en servidor:
Edge Function con una librería de generación de PDF (p. ej. Puppeteer
headless o una librería nativa de PDF en Deno/Node), reutilizando
`buildReportHtml()` como plantilla base y renderizándola a PDF en vez de
abrir una pestaña del navegador.

### 8. Analítica

Insertar en `analytics_events` (ya en el schema) en cada punto de enganche
listado en `ARCHITECTURE.md`, o enviar los mismos eventos a un proveedor
externo (PostHog, Amplitude) si se prefiere no acoplar analítica a la
base transaccional.
