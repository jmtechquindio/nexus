# ARCHITECTURE.md

## Flujo (sección 4 del prompt maestro)

```
VISITANTE → LANDING → FORMULARIO → NORMALIZACIÓN → MOTOR KIRMA V1
  → ANÁLISIS IA (opcional) → VALIDACIÓN → DIAGNÓSTICO FINAL → PERSISTENCIA
  → RESULTADO VISUAL → CONSENTIMIENTO → LEAD → DASHBOARD → SEGUIMIENTO COMERCIAL
```

La IA nunca es el único motor: `KirmaEngine.run(input, aiStages)` siempre
produce un diagnóstico completo aunque `aiStages` sea `null` (IA no
disponible o falló). El Motor V1 clasifica riesgo, contradicciones y
potencial usando solo reglas deterministas; la IA únicamente puede
enriquecer la lista de etapas detectadas, nunca la clasificación de
riesgo ni el veredicto final.

## Arquitectura híbrida (sección 5)

| Capa | Responsabilidad | Dónde vive |
|---|---|---|
| Reglas deterministas | Señales, riesgo, contradicciones, información faltante, clasificación base | `src/domain/kirma-engine/engine.js` |
| IA | Descomposición en etapas a partir de la descripción libre | `callAIProvider()` en `app.html`, vía capacidad `sample` |
| Validación | JSON bien formado, etapas con `automation_potential` válido | dentro de `callAIProvider()`; si falla, `aiStages = null` y el motor sigue con su heurística propia |

## Módulos

- **Motor KIRMA V1** (`src/domain/kirma-engine/engine.js`): puro,
  testeable sin interfaz. Ver `ENGINE.md`.
- **Formulario** (`app.html`, `FORM_STEPS`): 10 pasos visuales que
  recolectan las variables de la sección 7 (algunas variables técnicas
  —integración, personas, sensibilidad, complejidad— se piden como
  micro-preguntas dentro de los mismos 10 pasos, para no romper la
  simplicidad exigida en la sección 18).
- **AIProvider** (`app.html`, `callAIProvider()`): abstracción sobre la
  capacidad `sample`; en producción real esto se movería a un backend
  (ver `AI.md` y `DEPLOYMENT.md`).
- **Persistencia** (`app.html`, colecciones `diagnostics` y
  `diagnostic_activity` vía capacidad `db`): equivalente funcional de las
  tablas Supabase descritas en `SECURITY.md` y `/supabase/migrations`.
- **Dashboard** (`app.html`, `renderDashboard()`): KPIs, filtros, tabla,
  detalle con historial y cambio de estado.

## Eventos de analítica (sección 31 — definidos, no instrumentados aquí)

```
landing_view, diagnostic_started, diagnostic_completed, result_viewed,
report_downloaded, evaluation_requested, lead_created, status_changed
```

Embudo:

```
visitas → inicio → completado → resultado → evaluación solicitada
  → evaluación → propuesta → implementación
```

En producción, cada evento se registraría en una tabla `analytics_events`
(o un proveedor externo) en el momento exacto en que ocurre cada
transición dentro de `app.html`; los puntos de enganche ya existen como
funciones (`startForm`, `runDiagnosis`, `renderResult`, `downloadReport`,
`createLead`, `changeStatus`).
