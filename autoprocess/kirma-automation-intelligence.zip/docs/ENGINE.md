# ENGINE.md — Motor KIRMA V1

## Principio

El motor nunca dice "sí se puede" o "no se puede automatizar". Siempre
produce un veredicto de cuatro categorías, explicable y trazable, con un
`internal_score` que **nunca** se expone como porcentaje de éxito, ROI o
probabilidad.

## Entrada

```ts
{
  processDescription: string,
  frequency: 'multiple_daily'|'daily'|'multiple_weekly'|'weekly'|'monthly'|'occasional'|'unknown',
  volumeMonthly: number|null,
  minutesPerOp: number|null,
  structure: 'always'|'mostly'|'depends'|'always_different'|'unknown',
  exceptions: 'almost_never'|'sometimes'|'frequently'|'constantly'|'unknown',
  tools: string[],
  integration: 'api_available'|'no_integration'|'unknown',
  humanIntervention: '<25'|'25-50'|'50-75'|'>75'|'unknown',
  people: 'one'|'several'|'team'|'multiple_areas'|'third_parties',
  risk: 'low'|'medium'|'high'|'critical'|'unknown',
  sensitivity: 'yes'|'no'|'unknown',
  complexity: 'low'|'medium'|'high'|'unknown',
}
```

## Puntuación (uso exclusivamente interno)

Cada factor conocido aporta puntos (frecuencia, volumen, estructura,
excepciones, intervención humana: 0–3 c/u; riesgo y complejidad: −3 a +2;
integración: 0–2). Un factor `unknown` no puntúa y se agrega a
`missing_information` — la ausencia de información nunca se interpreta
como señal positiva (sección 11). El score se normaliza (`score / máximo
aplicable`) a un número entre 0 y 1 (`internal_score`), que jamás se
presenta como probabilidad.

## Clasificación forzada a `technical`

Independientemente del score, el veredicto es **REQUIERE EVALUACIÓN
TÉCNICA** si:

- se detectó alguna contradicción;
- `risk` es `high` o `critical`;
- hay 5 o más variables `unknown`;
- `sensitivity === 'yes'` y `risk` es `high`/`critical`.

Si no aplica ninguna de las anteriores, el veredicto sale del score
normalizado: `≥0.72` → alto potencial; `≥0.40` → potencial parcial;
si no, bajo potencial actual — nunca "imposible".

## Contradicciones detectadas (sección 10)

| Código | Condición |
|---|---|
| `VOLUME_WITH_ZERO_TIME` | volumen mensual > 100 y minutos por operación = 0 |
| `STRUCTURE_VS_HUMAN_DEPENDENCE` | estructura "siempre igual" + intervención humana > 75% |
| `NO_API_BUT_CLAIMS_INTEGRATION` | sin integración declarada pero la descripción afirma "totalmente integrado" |
| `CRITICAL_RISK_NO_OVERSIGHT` | riesgo crítico + intervención humana < 25% |

Cualquier contradicción fuerza `technical_potential = 'technical'` y
`confidence = 'low'`, y agrega la advertencia estándar de la sección 10.

## Descomposición en etapas

`decomposeStagesHeuristic()` es la versión **sin IA**: separa la
descripción en cláusulas y las compara contra un diccionario de verbos de
proceso (recibir, validar, registrar, decidir, notificar, conciliar,
negociar...). Es deliberadamente conservadora — no inventa etapas que no
tengan una coincidencia textual. Cuando la IA está disponible y devuelve
un JSON válido, sus etapas reemplazan a las de la heurística (ver `AI.md`
para las reglas de validación).

## Recomendación tecnológica (sección 14)

Mapeo fijo, nunca por moda: reglas claras → automatización basada en
reglas; ≥3 etapas → orquestación de flujo; API disponible → integración
API; sin API → evaluar RPA; documentos/PDF/imágenes → OCR/Document AI;
etapa de clasificación → IA de clasificación; etapa de decisión + riesgo
alto/crítico → IA con supervisión humana obligatoria; legacy sin API →
evaluar software a medida.

## Versionamiento (sección 35)

`engine_version` viaja en cada diagnóstico persistido
(`"KIRMA-V1"` en este entregable). Cambios futuros de reglas deben
incrementar la versión y nunca reescribir silenciosamente diagnósticos
históricos — el campo ya queda guardado por documento en `diagnostics`.

## Pruebas

`/tests/engine.test.js` cubre los 7 casos obligatorios de la sección 32
(A–G) más 4 reglas transversales (internal_score acotado 0–1, información
insuficiente fuerza `technical`+`low`, cálculo de horas, el motor nunca
dice "no se puede automatizar"). 13/13 en verde — ver `TESTING.md`.
