# TESTING.md

## Cómo correr las pruebas del motor

```bash
node tests/engine.test.js
```

Resultado actual: **13/13 pasaron**.

## Casos obligatorios (sección 32) y su resultado

| Caso | Escenario | Esperado | Obtenido |
|---|---|---|---|
| A | Facturas por correo, PDF, Excel, ERP, riesgo bajo | Alto potencial | ✅ `high` |
| B | Atención por WhatsApp, poco estructurado, excepciones frecuentes | Parcial o evaluación técnica | ✅ `partial` |
| C | Cartera vencida, negociación caso a caso, riesgo alto | Evaluación técnica | ✅ `technical` |
| D | Actualización de inventario, reglas claras, API disponible | Alto potencial | ✅ `high` |
| E | Aprobación de créditos grandes, riesgo crítico | Evaluación técnica | ✅ `technical` |
| F | Campaña creativa ocasional, subjetiva | Bajo potencial actual | ✅ `low` |
| G | 3 variantes de contradicción (volumen/tiempo, estructura/dependencia, riesgo crítico/sin supervisión) | Evaluación técnica + confianza baja | ✅ `technical` + `confidence: low` en las 3 |

## Reglas transversales probadas

- `internal_score` siempre es un número entre 0 y 1 — nunca se calcula ni
  se expone como porcentaje de éxito.
- Información insuficiente (muchos campos `unknown`) fuerza
  `technical` + `confidence: low`, nunca un veredicto optimista por
  omisión (sección 11).
- Cálculo de horas: `volumen × minutos / 60`, exacto.
- El motor nunca produce el texto "no se puede automatizar", ni siquiera
  en el caso de bajo potencial.

## Lo que falta para una cobertura de calidad tipo sección 33–34

Definido pero no ejecutado en este entregable (requiere backend real):

- **Trazabilidad completa**: entrada → diagnóstico → persistencia →
  dashboard → cambio de estado → historial → consentimiento → lead →
  diagnóstico sin lead cuando no hay consentimiento. La lógica ya existe
  en `app.html` (`runDiagnosis`, `createLead`, `changeStatus`) y se probó
  manualmente durante la construcción, pero no hay pruebas de integración
  automatizadas contra una base de datos real en este entregable.
- **Calidad del motor vs. evaluación humana** (sección 34): requiere un
  conjunto de procesos reales de KIRMA-SOFT evaluados por un humano
  experto para comparar contra el motor y registrar coincidencia/
  discrepancia/razón — no existe ese conjunto de referencia en este
  entregable, así que no se puede fabricar sin inventar datos.

## Cómo extender la suite

Cada nuevo caso de prueba debe:

1. Llamar a `runKirmaEngine(input)` con un input completo y realista.
2. Afirmar el `technical_potential` esperado y, cuando aplique,
   `confidence` y/o `contradictions`.
3. Nunca ajustar las reglas del motor solo para hacer pasar una prueba
   sin justificar el cambio en `ENGINE.md` (sección 34: "no modificar las
   reglas simplemente para aumentar artificialmente la tasa de
   coincidencia").
