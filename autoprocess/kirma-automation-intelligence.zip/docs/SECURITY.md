# SECURITY.md

## Lo que exige el prompt maestro (sección 24)

RLS, roles, validación server-side, sanitización, rate limiting,
CAPTCHA/Turnstile, secretos en backend (nunca API keys en frontend),
logs, auditoría, protección contra abuso, backups. `viewer` nunca
modifica; solo `admin`/`sales` cambian estados.

## Estado real en este entregable

| Requisito | Estado en `app.html` (prototipo publicado) | Cómo llevarlo a producción |
|---|---|---|
| Roles admin/sales/viewer | **No implementado como control de acceso real.** Hay un interruptor de interfaz "Portal cliente / Equipo KIRMA" — es solo navegación, cualquiera puede tocarlo. | Autenticación real (Supabase Auth) + tabla `user_profiles.role` + RLS (`/supabase/migrations/0002_rls.sql`), que ya deniega `UPDATE` en `diagnostics` a todo el que no sea `admin`/`sales`. |
| RLS | No aplica — el almacenamiento (`db`) del artefacto usa reglas de nivel `interact`/`admin` del propio visor, no roles de negocio. | Migraciones SQL listas en `/supabase/migrations`. |
| Secrets en backend | Cumplido: la IA corre vía la capacidad `sample`, que nunca expone una API key al frontend. | La Edge Function de referencia (`/supabase/functions/ai-diagnose`) muestra dónde vivirían las claves de un proveedor propio si se reemplaza `sample`. |
| Rate limiting / CAPTCHA | No implementado — no hay superficie de abuso real en un artefacto compartido de forma privada, pero un formulario público sí la necesita. | Turnstile/reCAPTCHA en el paso de contacto + rate limiting en la Edge Function que procese el formulario. |
| Validación server-side | Parcial — el Motor KIRMA valida y normaliza la entrada (`normalizeInput`), pero corre en el cliente. | Repetir la misma validación en la Edge Function antes de persistir, nunca confiar solo en el cliente. |
| Sanitización | Las salidas a HTML pasan por `esc()` para evitar inyección al renderizar datos guardados por visitantes (nombre, empresa, descripción). | Igual en el backend: sanitizar antes de persistir, no solo antes de mostrar. |
| Auditoría | Cumplido en el modelo de datos: `diagnostic_activity` registra quién, qué, cuándo, estado anterior/nuevo y nota, para cada cambio. | Igual en producción; agregar logging de acceso (quién leyó qué) si el volumen de datos sensibles lo justifica. |
| Backups | No aplica en el prototipo (el almacenamiento lo gestiona la plataforma del artefacto). | Backups automáticos de Supabase (point-in-time recovery). |
| Nunca `viewer → modificar` | No garantizado en el prototipo (ver roles arriba). | Garantizado por `0002_rls.sql`: solo la policy de `UPDATE` permite `admin`/`sales`. |

## Por qué esta limitación es aceptable en este entregable y no en producción

Un artefacto de Claude sirve datos organization-internal — no expone
puertos, no tiene base de datos pública en internet, y el "Equipo KIRMA"
como interruptor es una conveniencia de demo, no una superficie de
ataque real hacia datos de terceros fuera de la organización que lo
comparte. Pero **no cumple** el requisito explícito de la sección 24 de
que `viewer` nunca pueda modificar — por eso este documento lo declara
sin rodeos en vez de simularlo.

## Checklist de auto-revisión (sección 39, columna seguridad)

- ¿Un usuario no autorizado puede leer datos de otro? → En el prototipo,
  cualquiera con el enlace del artefacto puede leer todos los
  diagnósticos (comportamiento por defecto de `db` para visores
  `interact`+). En producción, RLS limita lectura a usuarios autenticados
  con perfil en `user_profiles`.
- ¿Puede modificar datos sin autorización? → Sí, en el prototipo (ver
  tabla arriba). No, en producción con `0002_rls.sql` aplicado.
- ¿Las API keys de IA quedan expuestas? → No, en ninguno de los dos
  casos (capacidad `sample` o Edge Function con secreto de servidor).
