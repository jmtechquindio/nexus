# AI.md — Integración de IA

## Principio (sección 26)

La IA solo hace una cosa en este MVP: **descomponer la descripción libre
del proceso en etapas**. No decide el veredicto, no calcula riesgo, no
inventa ahorro. El prompt interno exige explícitamente:

1. No inventar. 2. No inventar etapas. 3. No inventar ahorro.
4. No inventar herramientas. 5. Identificar incertidumbre.
6. Detectar contradicciones (las contradicciones "duras" las detecta el
   motor, no la IA — ver `ENGINE.md`). 7. Devolver JSON. 8. Separar
   automatización de supervisión (`human_required`). 9. Explicar
   conclusiones. 10. Respetar únicamente los datos recibidos.

## Dónde vive en este entregable

`callAIProvider(input)` en `app.html`, usando la capacidad `sample` del
artefacto (`await claude.use('sample')`). Esto es un **AIProvider real**,
no un mock: llama a un modelo de verdad, con la petición de JSON
estructurado que exige la sección 26.

```js
const stages = await S.sample.json(prompt, {modelTier:'quick', cache:true});
```

## Validación antes de usar el resultado (sección 26, "Validar el JSON
antes de persistirlo")

```js
const valid = stages.filter(s =>
  s && typeof s.name === 'string' &&
  ['high','partial','low','unknown'].includes(s.automation_potential)
).map(s => ({ name: s.name.slice(0,80), automation_potential: s.automation_potential, human_required: !!s.human_required }));
return valid.length ? valid : null;
```

Cualquier etapa que no cumpla la forma esperada se descarta. Si el
resultado final queda vacío, o `sample.json` rechaza por cualquier
motivo (`not_granted`, `rate_limited`, `invalid_json`, etc.),
`callAIProvider` devuelve `null` — nunca lanza un error que rompa el
flujo.

## Fallback (sección 27)

```
IA → error/null → Motor KIRMA V1 (decomposeStagesHeuristic) → diagnóstico completo igual
```

`KirmaEngine.run(input, aiStages)` usa `aiStages` solo si no es `null` y
tiene al menos un elemento; en cualquier otro caso corre su propia
heurística determinista de etapas. El resultado visible incluye
`ai_used: true/false` para que quede trazable en el dashboard qué
diagnósticos usaron IA y cuáles no.

## Diferencia con producción real (Supabase + Edge Function)

En este entregable la IA corre **client-side, vía la capacidad `sample`
del artefacto** (paga el visor, no hay API key expuesta porque la
capacidad no expone ninguna clave al frontend). En una implementación
con Supabase, esa misma responsabilidad se movería a una Edge Function —
ver `/supabase/functions/ai-diagnose/index.ts` — para: (a) usar la API
key del proveedor de IA que ustedes elijan, guardada como secreto de
servidor, nunca en el frontend; (b) aplicar rate limiting y logging
centralizados; (c) validar el JSON en el servidor antes de que llegue al
cliente. La forma del contrato (prompt → JSON de etapas → validación →
fallback al motor) es idéntica; solo cambia dónde corre.
