/**
 * KIRMA AUTOMATION INTELLIGENCE — Motor KIRMA V1
 * ------------------------------------------------
 * Módulo de dominio puro, sin dependencias de UI ni de red.
 * Recibe las respuestas normalizadas del formulario y devuelve
 * un diagnóstico estructurado (ver DIAGNOSTIC_SCHEMA_VERSION).
 *
 * Principio: el motor NUNCA garantiza ahorro, ROI ni porcentajes
 * de automatización definitivos. Solo produce un indicador
 * preliminar, explicable y trazable.
 *
 * Funciona 100% sin IA. La IA (cuando está disponible) solo
 * enriquece la descomposición en etapas y la redacción de la
 * explicación; nunca sustituye la clasificación de riesgo/potencial.
 */

const ENGINE_VERSION = 'KIRMA-V1';

// ---------------------------------------------------------------------------
// Vocabularios de entrada válidos (normalización defensiva)
// ---------------------------------------------------------------------------

const FREQUENCY_VALUES = [
  'multiple_daily', 'daily', 'multiple_weekly', 'weekly', 'monthly', 'occasional',
];

const STRUCTURE_VALUES = ['always', 'mostly', 'depends', 'always_different', 'unknown'];
const EXCEPTIONS_VALUES = ['almost_never', 'sometimes', 'frequently', 'constantly', 'unknown'];
const HUMAN_INTERVENTION_VALUES = ['<25', '25-50', '50-75', '>75', 'unknown'];
const RISK_VALUES = ['low', 'medium', 'high', 'critical', 'unknown'];
const COMPLEXITY_VALUES = ['low', 'medium', 'high', 'unknown'];
const INTEGRATION_VALUES = ['api_available', 'no_integration', 'unknown'];
const PEOPLE_VALUES = ['one', 'several', 'team', 'multiple_areas', 'third_parties'];
const SENSITIVITY_VALUES = ['yes', 'no', 'unknown'];

const STRUCTURED_TOOLS = new Set(['excel', 'csv', 'erp', 'crm', 'database', 'api']);
const UNSTRUCTURED_TOOLS = new Set(['email', 'pdf', 'documents', 'images', 'whatsapp', 'legacy', 'custom_software', 'other']);

// ---------------------------------------------------------------------------
// Puntos por factor (contribuyen a internal_score, uso EXCLUSIVAMENTE interno)
// ---------------------------------------------------------------------------

const FREQUENCY_POINTS = {
  multiple_daily: 3, daily: 3, multiple_weekly: 2, weekly: 2, monthly: 1, occasional: 0,
};
const STRUCTURE_POINTS = { always: 3, mostly: 2, depends: 1, always_different: 0 };
const EXCEPTIONS_POINTS = { almost_never: 3, sometimes: 2, frequently: 1, constantly: 0 };
const HUMAN_INTERVENTION_POINTS = { '<25': 3, '25-50': 2, '50-75': 1, '>75': 0 };
const RISK_POINTS = { low: 2, medium: 1, high: -2, critical: -3 };
const COMPLEXITY_POINTS = { low: 2, medium: 1, high: -1 };
const INTEGRATION_POINTS = { api_available: 2, no_integration: 0 };

const MAX_POSSIBLE_SCORE = 3 + 3 + 3 + 3 + 3 + 2 + 2 + 2; // freq+vol+struct+excep+human+risk+complexity+integration

// ---------------------------------------------------------------------------
// Utilidades
// ---------------------------------------------------------------------------

function volumePoints(volumeMonthly) {
  if (volumeMonthly === null || volumeMonthly === undefined || Number.isNaN(volumeMonthly)) return null;
  if (volumeMonthly > 300) return 3;
  if (volumeMonthly > 80) return 2;
  if (volumeMonthly > 15) return 1;
  return 0;
}

function classifyToolset(tools = []) {
  const structured = tools.filter((t) => STRUCTURED_TOOLS.has(t));
  const unstructured = tools.filter((t) => UNSTRUCTURED_TOOLS.has(t));
  return { structured, unstructured };
}

function isUnknown(v) {
  return v === undefined || v === null || v === '' || v === 'unknown';
}

// ---------------------------------------------------------------------------
// 1) Recolección de factores + información faltante
// ---------------------------------------------------------------------------

function collectFactors(input) {
  const factors = [];
  const missing = [];
  let score = 0;
  let maxApplicable = 0;

  // Frecuencia
  if (isUnknown(input.frequency)) {
    missing.push('frequency');
  } else {
    const pts = FREQUENCY_POINTS[input.frequency] ?? 0;
    score += pts; maxApplicable += 3;
    factors.push({ key: 'frequency', value: input.frequency, points: pts, label: 'Frecuencia del proceso' });
  }

  // Volumen
  const volPts = volumePoints(input.volumeMonthly);
  if (volPts === null) {
    missing.push('volumeMonthly');
  } else {
    score += volPts; maxApplicable += 3;
    factors.push({ key: 'volume', value: input.volumeMonthly, points: volPts, label: 'Volumen mensual de operaciones' });
  }

  // Estructura
  if (isUnknown(input.structure)) {
    missing.push('structure');
  } else {
    const pts = STRUCTURE_POINTS[input.structure] ?? 0;
    score += pts; maxApplicable += 3;
    factors.push({ key: 'structure', value: input.structure, points: pts, label: 'Grado de estructura del proceso' });
  }

  // Excepciones
  if (isUnknown(input.exceptions)) {
    missing.push('exceptions');
  } else {
    const pts = EXCEPTIONS_POINTS[input.exceptions] ?? 0;
    score += pts; maxApplicable += 3;
    factors.push({ key: 'exceptions', value: input.exceptions, points: pts, label: 'Frecuencia de excepciones' });
  }

  // Intervención humana
  if (isUnknown(input.humanIntervention)) {
    missing.push('humanIntervention');
  } else {
    const pts = HUMAN_INTERVENTION_POINTS[input.humanIntervention] ?? 0;
    score += pts; maxApplicable += 3;
    factors.push({ key: 'humanIntervention', value: input.humanIntervention, points: pts, label: 'Nivel de intervención humana' });
  }

  // Riesgo
  if (isUnknown(input.risk)) {
    missing.push('risk');
  } else {
    const pts = RISK_POINTS[input.risk] ?? 0;
    score += pts; maxApplicable += 2;
    factors.push({ key: 'risk', value: input.risk, points: pts, label: 'Riesgo asociado a un error' });
  }

  // Complejidad
  if (isUnknown(input.complexity)) {
    missing.push('complexity');
  } else {
    const pts = COMPLEXITY_POINTS[input.complexity] ?? 0;
    score += pts; maxApplicable += 2;
    factors.push({ key: 'complexity', value: input.complexity, points: pts, label: 'Complejidad del proceso' });
  }

  // Integración
  if (isUnknown(input.integration)) {
    missing.push('integration');
  } else {
    const pts = INTEGRATION_POINTS[input.integration] ?? 0;
    score += pts; maxApplicable += 2;
    factors.push({ key: 'integration', value: input.integration, points: pts, label: 'Disponibilidad de integración (API)' });
  }

  // Herramientas / información (no puntúa directamente el score, pero informa recomendación)
  const { structured, unstructured } = classifyToolset(input.tools || []);
  if (!input.tools || input.tools.length === 0) {
    missing.push('tools');
  } else {
    factors.push({
      key: 'tools',
      value: input.tools,
      points: null,
      label: `Herramientas: ${structured.length} digitales estructuradas, ${unstructured.length} no estructuradas`,
    });
  }

  // Descripción del proceso (claridad)
  const description = (input.processDescription || '').trim();
  if (description.length < 15) {
    missing.push('processDescription');
  }

  return { factors, missing, score, maxApplicable, structuredTools: structured, unstructuredTools: unstructured, description };
}

// ---------------------------------------------------------------------------
// 2) Detección de contradicciones (sección 10 del prompt maestro)
// ---------------------------------------------------------------------------

function detectContradictions(input) {
  const contradictions = [];

  // volumen muy alto + tiempo por operación en cero
  if ((input.volumeMonthly ?? 0) > 100 && input.minutesPerOp === 0) {
    contradictions.push({
      code: 'VOLUME_WITH_ZERO_TIME',
      message: 'Se declaró un volumen mensual alto junto con un tiempo por operación de cero minutos.',
    });
  }

  // "automatización total" (estructura siempre igual) + dependencia humana >75%
  if (input.structure === 'always' && input.humanIntervention === '>75') {
    contradictions.push({
      code: 'STRUCTURE_VS_HUMAN_DEPENDENCE',
      message: 'El proceso se describe como siempre estructurado igual, pero también con más del 75% de intervención humana.',
    });
  }

  // API inexistente + descripción que afirma integración total
  const desc = (input.processDescription || '').toLowerCase();
  const claimsFullIntegration = /(totalmente integrado|integraci[oó]n total|todo conectado|sistema unificado)/.test(desc);
  if (input.integration === 'no_integration' && claimsFullIntegration) {
    contradictions.push({
      code: 'NO_API_BUT_CLAIMS_INTEGRATION',
      message: 'Se indicó que no existe integración disponible, pero la descripción afirma que el proceso está totalmente integrado.',
    });
  }

  // riesgo crítico + ausencia de supervisión (intervención humana muy baja)
  if (input.risk === 'critical' && input.humanIntervention === '<25') {
    contradictions.push({
      code: 'CRITICAL_RISK_NO_OVERSIGHT',
      message: 'El proceso se declara de riesgo crítico pero con intervención humana muy baja (posible ausencia de supervisión).',
    });
  }

  return contradictions;
}

// ---------------------------------------------------------------------------
// 3) Descomposición en etapas — heurística determinista (fallback sin IA)
// ---------------------------------------------------------------------------

const STAGE_DICTIONARY = [
  { pattern: /(recib|llega|entra)/i, name: 'Recepción', potential: 'high', humanRequired: false },
  { pattern: /(descarg|obten|extra(e|jo)|captur)/i, name: 'Obtención / extracción de información', potential: 'high', humanRequired: false },
  { pattern: /(valid|revis|verific|chequ)/i, name: 'Validación', potential: 'partial', humanRequired: true },
  { pattern: /(registr|carg|ingres|guard)/i, name: 'Registro / carga en sistema', potential: 'high', humanRequired: false },
  { pattern: /(clasific|categoriz|orden)/i, name: 'Clasificación', potential: 'partial', humanRequired: true },
  { pattern: /(decid|aprob|autoriz|evalu(a|ó))/i, name: 'Decisión / aprobación', potential: 'partial', humanRequired: true },
  { pattern: /(notif|envi|inform|confirm)/i, name: 'Notificación / confirmación', potential: 'high', humanRequired: false },
  { pattern: /(concili|cuadr|cruc)/i, name: 'Conciliación', potential: 'partial', humanRequired: true },
  { pattern: /(negoci|convenc|persuad|resuelv|atiend)/i, name: 'Interacción / negociación', potential: 'low', humanRequired: true },
];

function decomposeStages(description) {
  if (!description || description.trim().length < 15) return [];
  const clauses = description
    .split(/,|;|\by luego\b|\bdespués\b|\bentonces\b|\.\s/i)
    .map((c) => c.trim())
    .filter(Boolean);

  const found = [];
  const seenNames = new Set();
  for (const clause of clauses) {
    for (const rule of STAGE_DICTIONARY) {
      if (rule.pattern.test(clause) && !seenNames.has(rule.name)) {
        found.push({ name: rule.name, automation_potential: rule.potential, human_required: rule.humanRequired });
        seenNames.add(rule.name);
      }
    }
  }
  return found;
}

// ---------------------------------------------------------------------------
// 4) Recomendación tecnológica (mapeo fijo, sección 14)
// ---------------------------------------------------------------------------

function recommendTechnologies({ input, structuredTools, unstructuredTools, stages }) {
  const recs = new Set();

  const hasDocs = (input.tools || []).some((t) => ['pdf', 'documents', 'images'].includes(t));
  const hasLegacy = (input.tools || []).includes('legacy');
  const hasClassificationStage = stages.some((s) => s.name.includes('Clasificación') || s.name.includes('Decisión'));
  const hasCriticalDecision = stages.some((s) => s.name.includes('Decisión')) && ['high', 'critical'].includes(input.risk);

  if (input.structure === 'always' || input.structure === 'mostly') recs.add('Automatización basada en reglas');
  if (stages.length >= 3) recs.add('Orquestación de flujo (workflow)');
  if (input.integration === 'api_available') recs.add('Integración vía API');
  if (input.integration === 'no_integration') recs.add('Evaluar RPA (automatización robótica de procesos)');
  if (hasDocs) recs.add('OCR / Document AI para digitalizar documentos');
  if (hasClassificationStage) recs.add('IA para clasificación / interpretación de contenido');
  if (hasCriticalDecision) recs.add('IA con supervisión humana obligatoria (decisión crítica)');
  if (hasLegacy && input.integration !== 'api_available') recs.add('Evaluar desarrollo de software a medida (sistema legacy insuficiente)');

  if (recs.size === 0) recs.add('Evaluación técnica manual (información insuficiente para recomendar tecnología)');

  return Array.from(recs);
}

// ---------------------------------------------------------------------------
// 5) Clasificación final
// ---------------------------------------------------------------------------

function classify({ score, maxApplicable, missing, contradictions, input }) {
  const forcedTechnical =
    contradictions.length > 0 ||
    input.risk === 'high' ||
    input.risk === 'critical' ||
    missing.length >= 5 ||
    (input.sensitivity === 'yes' && ['high', 'critical'].includes(input.risk));

  let technical_potential;
  const normalizedScore = maxApplicable > 0 ? score / maxApplicable : 0;

  if (forcedTechnical) {
    technical_potential = 'technical';
  } else if (normalizedScore >= 0.72) {
    technical_potential = 'high';
  } else if (normalizedScore >= 0.4) {
    technical_potential = 'partial';
  } else {
    technical_potential = 'low';
  }

  // Confianza
  let confidence;
  if (contradictions.length > 0) {
    confidence = 'low';
  } else if (missing.length === 0) {
    confidence = 'high';
  } else if (missing.length <= 2) {
    confidence = 'medium';
  } else {
    confidence = 'low';
  }

  // Prioridad de evaluación comercial
  let evaluation_priority;
  if (technical_potential === 'high' || technical_potential === 'technical') {
    evaluation_priority = 'high';
  } else if (technical_potential === 'partial') {
    evaluation_priority = 'medium';
  } else {
    evaluation_priority = 'low';
  }

  // Calidad de información
  const descLen = (input.processDescription || '').trim().length;
  let information_quality;
  if (descLen > 80 && missing.length <= 1) information_quality = 'high';
  else if (descLen > 30 && missing.length <= 3) information_quality = 'medium';
  else information_quality = 'low';

  return {
    technical_potential,
    confidence,
    evaluation_priority,
    information_quality,
    internal_score: Math.round(normalizedScore * 100) / 100,
  };
}

const RECOMMENDATION_TEXT = {
  high: 'El proceso presenta varias características favorables para estudiar una automatización. La viabilidad definitiva debe validarse técnicamente.',
  partial: 'Ciertas etapas del proceso muestran potencial de automatización, mientras otras requieren mantener supervisión o criterio humano.',
  technical: 'Hay información que debe validarse antes de emitir una conclusión más específica sobre el potencial de automatización.',
  low: 'En su forma actual, el proceso presenta baja frecuencia o alta variabilidad, lo que limita el potencial de automatización inmediato. Esto no significa que no pueda automatizarse en el futuro.',
};

const TITLE_TEXT = {
  high: 'ALTO POTENCIAL',
  partial: 'POTENCIAL PARCIAL',
  technical: 'REQUIERE EVALUACIÓN TÉCNICA',
  low: 'BAJO POTENCIAL ACTUAL',
};

// ---------------------------------------------------------------------------
// 6) Punto de entrada público
// ---------------------------------------------------------------------------

function runKirmaEngine(rawInput) {
  const input = normalizeInput(rawInput);

  const { factors, missing, score, maxApplicable, structuredTools, unstructuredTools, description } = collectFactors(input);
  const contradictions = detectContradictions(input);
  const stages = decomposeStages(description);
  const classification = classify({ score, maxApplicable, missing, contradictions, input });
  const technologies = recommendTechnologies({ input, structuredTools, unstructuredTools, stages });

  const warnings = [];
  if (contradictions.length > 0) {
    warnings.push('Hay información que debe validarse antes de emitir una conclusión más específica.');
  }
  if (missing.length >= 3) {
    warnings.push('Falta información relevante; el diagnóstico se basa en datos parciales.');
  }

  let hoursEstimatedMonthly = null;
  if (input.volumeMonthly && input.minutesPerOp) {
    hoursEstimatedMonthly = Math.round(((input.volumeMonthly * input.minutesPerOp) / 60) * 10) / 10;
  }

  return {
    engine_version: ENGINE_VERSION,
    technical_potential: classification.technical_potential,
    title: TITLE_TEXT[classification.technical_potential],
    evaluation_priority: classification.evaluation_priority,
    information_quality: classification.information_quality,
    confidence: classification.confidence,
    internal_score: classification.internal_score,
    factors,
    contradictions,
    missing_information: missing,
    stages,
    recommendation: RECOMMENDATION_TEXT[classification.technical_potential],
    recommended_technologies: technologies,
    hours_estimated_monthly: hoursEstimatedMonthly,
    warnings,
  };
}

function normalizeInput(raw) {
  const input = { ...raw };
  if (!FREQUENCY_VALUES.includes(input.frequency)) input.frequency = input.frequency || 'unknown';
  if (!STRUCTURE_VALUES.includes(input.structure)) input.structure = input.structure || 'unknown';
  if (!EXCEPTIONS_VALUES.includes(input.exceptions)) input.exceptions = input.exceptions || 'unknown';
  if (!HUMAN_INTERVENTION_VALUES.includes(input.humanIntervention)) input.humanIntervention = input.humanIntervention || 'unknown';
  if (!RISK_VALUES.includes(input.risk)) input.risk = input.risk || 'unknown';
  if (!COMPLEXITY_VALUES.includes(input.complexity)) input.complexity = input.complexity || 'unknown';
  if (!INTEGRATION_VALUES.includes(input.integration)) input.integration = input.integration || 'unknown';
  if (!SENSITIVITY_VALUES.includes(input.sensitivity)) input.sensitivity = input.sensitivity || 'unknown';
  input.tools = Array.isArray(input.tools) ? input.tools : [];
  input.volumeMonthly = typeof input.volumeMonthly === 'number' ? input.volumeMonthly : null;
  input.minutesPerOp = typeof input.minutesPerOp === 'number' ? input.minutesPerOp : null;
  input.processDescription = input.processDescription || '';
  return input;
}

module.exports = {
  runKirmaEngine,
  ENGINE_VERSION,
  // exportados para testing / inspección
  detectContradictions,
  decomposeStages,
  classify,
};
