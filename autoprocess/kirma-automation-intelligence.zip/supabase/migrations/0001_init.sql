-- KIRMA Automation Intelligence — schema de referencia (sección 23)
-- Este archivo NO está desplegado. Es la base para crear el proyecto
-- Supabase real y aplicar la seguridad descrita en SECURITY.md.

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------
-- user_profiles: uno por usuario de auth.users, define el rol de negocio
-- ---------------------------------------------------------------------
create type kirma_role as enum ('admin', 'sales', 'viewer');

create table user_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  role kirma_role not null default 'viewer'
);

-- ---------------------------------------------------------------------
-- diagnostics
-- ---------------------------------------------------------------------
create type diagnostic_status as enum (
  'Nuevo','Contactado','Evaluación','Propuesta','Implementación','Cerrado','No continuar'
);
create type technical_potential_t as enum ('high','partial','technical','low');
create type confidence_t as enum ('high','medium','low');
create type priority_t as enum ('high','medium','low');

create table diagnostics (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  name text,
  company text,
  email text,
  phone text,
  answers jsonb not null,             -- respuestas normalizadas del formulario
  result jsonb not null,              -- salida completa del Motor KIRMA (ver ENGINE.md)
  stages jsonb not null default '[]', -- copia indexable de result.stages
  confidence confidence_t not null,
  technical_potential technical_potential_t not null,
  evaluation_priority priority_t not null,
  consent boolean not null default false,
  source text not null default 'landing',
  status diagnostic_status not null default 'Nuevo',
  status_updated_at timestamptz not null default now(),
  status_updated_by text
);

create index diagnostics_created_at_idx on diagnostics (created_at desc);
create index diagnostics_status_idx on diagnostics (status);
create index diagnostics_technical_potential_idx on diagnostics (technical_potential);
create index diagnostics_consent_idx on diagnostics (consent);

-- ---------------------------------------------------------------------
-- diagnostic_activity
-- ---------------------------------------------------------------------
create table diagnostic_activity (
  id uuid primary key default gen_random_uuid(),
  diagnostic_id uuid not null references diagnostics(id) on delete cascade,
  actor text not null,
  activity_type text not null,        -- 'lead_created' | 'status_changed' | ...
  from_status diagnostic_status,
  to_status diagnostic_status,
  note text,
  created_at timestamptz not null default now()
);

create index diagnostic_activity_diagnostic_id_idx on diagnostic_activity (diagnostic_id);

-- ---------------------------------------------------------------------
-- analytics_events (sección 31, opcional pero recomendado desde el día 1)
-- ---------------------------------------------------------------------
create table analytics_events (
  id uuid primary key default gen_random_uuid(),
  event_type text not null,           -- landing_view | diagnostic_started | ...
  diagnostic_id uuid references diagnostics(id) on delete set null,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);
