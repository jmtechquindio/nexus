-- Row Level Security — sección 24: solo admin/sales pueden modificar
-- estados; viewer nunca modifica; el formulario público (rol anónimo)
-- solo puede INSERTAR un diagnóstico, nunca leer ni modificar los de
-- otros.

alter table diagnostics enable row level security;
alter table diagnostic_activity enable row level security;
alter table user_profiles enable row level security;
alter table analytics_events enable row level security;

-- Helper: rol del usuario autenticado actual
create or replace function current_kirma_role() returns kirma_role
language sql stable security definer as $$
  select role from user_profiles where id = auth.uid();
$$;

-- user_profiles: cada quien ve su propio perfil; admin ve todos
create policy "profiles_self_select" on user_profiles
  for select using (id = auth.uid() or current_kirma_role() = 'admin');

-- diagnostics -----------------------------------------------------------

-- El formulario público (visitante anónimo, vía la app, nunca vía el
-- dashboard) puede CREAR un diagnóstico, pero no leer ni modificar los
-- de nadie. La app usa una función RPC (`submit_diagnostic`, no
-- incluida aquí) o una Edge Function para insertar en nombre del
-- visitante, en vez de exponer INSERT directo desde el cliente.
create policy "diagnostics_insert_anon" on diagnostics
  for insert to anon with check (true);

-- admin y sales leen todo; viewer lee todo (solo lectura); nadie más.
create policy "diagnostics_select_team" on diagnostics
  for select to authenticated
  using (current_kirma_role() in ('admin','sales','viewer'));

-- Solo admin y sales pueden modificar (cambiar estado, etc.). viewer NO.
create policy "diagnostics_update_admin_sales" on diagnostics
  for update to authenticated
  using (current_kirma_role() in ('admin','sales'))
  with check (current_kirma_role() in ('admin','sales'));

-- Nadie borra diagnósticos vía API (auditoría/backup, sección 24).
-- No se crea policy de DELETE → queda denegado por defecto.

-- diagnostic_activity -----------------------------------------------------

create policy "activity_select_team" on diagnostic_activity
  for select to authenticated
  using (current_kirma_role() in ('admin','sales','viewer'));

create policy "activity_insert_admin_sales" on diagnostic_activity
  for insert to authenticated
  with check (current_kirma_role() in ('admin','sales'));

-- El propio flujo de "lead creado con consentimiento" lo inserta la
-- Edge Function que procesa el formulario (rol de servicio), no el
-- cliente anónimo directamente.

-- analytics_events --------------------------------------------------------

create policy "analytics_insert_service" on analytics_events
  for insert to service_role with check (true);

create policy "analytics_select_team" on analytics_events
  for select to authenticated
  using (current_kirma_role() in ('admin','sales'));
