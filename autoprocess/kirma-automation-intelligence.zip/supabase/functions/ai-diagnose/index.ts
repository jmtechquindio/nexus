// Edge Function de referencia — mueve callAIProvider() del cliente al
// servidor para producción real. NO desplegada en este entregable.
//
// Contrato: recibe { processDescription }, devuelve { stages } o
// { stages: null, reason } si la IA no está disponible/falla — el
// frontend, igual que hoy, debe seguir funcionando con el fallback
// determinista del Motor KIRMA V1 cuando stages es null.
//
// Variables de entorno esperadas (nunca en el frontend):
//   AI_PROVIDER_API_KEY

import { serve } from "https://deno.land/std@0.203.0/http/server.ts";

const ALLOWED_POTENTIAL = new Set(["high", "partial", "low", "unknown"]);

function validateStages(raw: unknown): { name: string; automation_potential: string; human_required: boolean }[] | null {
  if (!Array.isArray(raw)) return null;
  const valid = raw
    .filter((s) => s && typeof s === "object" && typeof (s as any).name === "string" && ALLOWED_POTENTIAL.has((s as any).automation_potential))
    .map((s: any) => ({
      name: String(s.name).slice(0, 80),
      automation_potential: s.automation_potential,
      human_required: !!s.human_required,
    }))
    .slice(0, 8);
  return valid.length ? valid : null;
}

serve(async (req) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "method_not_allowed" }), { status: 405 });
  }

  let body: { processDescription?: string };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "invalid_json" }), { status: 400 });
  }

  const description = (body.processDescription || "").trim();
  if (description.length < 15) {
    // Regla 1 del prompt de IA: no inventar. Sin texto suficiente, no se llama al modelo.
    return new Response(JSON.stringify({ stages: null, reason: "insufficient_input" }), { status: 200 });
  }

  const apiKey = Deno.env.get("AI_PROVIDER_API_KEY");
  if (!apiKey) {
    return new Response(JSON.stringify({ stages: null, reason: "ai_not_configured" }), { status: 200 });
  }

  const prompt = [
    "Eres un analista de procesos B2B. Descompón el siguiente proceso en etapas reales, SOLO con base en el texto dado.",
    "Reglas estrictas: 1) No inventes etapas que no estén implícitas en el texto. 2) No inventes ahorro ni ROI.",
    '3) Cada etapa debe tener automation_potential en {"high","partial","low","unknown"} y human_required boolean.',
    "4) Responde ÚNICAMENTE un array JSON de objetos {\"name\": string, \"automation_potential\": string, \"human_required\": boolean}, sin texto adicional.",
    "Máximo 8 etapas.",
    "",
    "Proceso descrito por el usuario:",
    description,
  ].join("\n");

  try {
    // Sustituir por la llamada real al proveedor de IA elegido (Anthropic,
    // OpenAI, etc.), usando `apiKey` únicamente aquí, nunca en el cliente.
    const aiResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-6",
        max_tokens: 800,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!aiResponse.ok) {
      return new Response(JSON.stringify({ stages: null, reason: "upstream_error" }), { status: 200 });
    }

    const data = await aiResponse.json();
    const text = (data.content || []).map((b: any) => b.text || "").join("\n");
    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch {
      const match = text.match(/\[[\s\S]*\]/);
      parsed = match ? JSON.parse(match[0]) : null;
    }

    const stages = validateStages(parsed);
    return new Response(JSON.stringify({ stages }), { status: 200 });
  } catch (_err) {
    // Fallback: el frontend recibe stages: null y sigue con el Motor
    // KIRMA V1 determinista (sección 27). Nunca se deja el sistema
    // inutilizable por un fallo de IA.
    return new Response(JSON.stringify({ stages: null, reason: "exception" }), { status: 200 });
  }
});
