const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '..', 'app.html'), 'utf8');

/* ---------------------------------------------------------------------
   Mock de la capacidad `db` — implementa el mismo contrato descrito en
   el runtime real (doc/collection/set/update/add/where/orderBy/limit/
   get/onSnapshot) para poder ejercitar de verdad runDiagnosis(),
   createLead(), subscribeDiagnostics() y changeStatus() tal como están
   escritos en app.html, sin inventar una API paralela.
   --------------------------------------------------------------------- */
function makeMockDb(){
  const store = {}; // path -> { id: data }
  let counter = 0;
  const listeners = {}; // collectionPath -> [cb]

  function notify(collPath){
    (listeners[collPath]||[]).forEach(cb=>{
      const docs = Object.entries(store[collPath]||{}).map(([id,data])=>({ id, exists:true, data:()=>data }));
      cb({ docs, size: docs.length, empty: docs.length===0, docChanges:()=>[] });
    });
  }

  function collection(collPath){
    store[collPath] = store[collPath] || {};
    const api = {
      path: collPath,
      doc(id){
        const docId = id || ('doc_' + (++counter));
        return {
          id: docId,
          path: collPath + '/' + docId,
          async set(data){ store[collPath][docId] = Object.assign({}, data); notify(collPath); },
          async update(data){
            if(!store[collPath][docId]) throw {code:'invalid_argument', message:'not found'};
            store[collPath][docId] = Object.assign({}, store[collPath][docId], data);
            notify(collPath);
          },
          async delete(){ delete store[collPath][docId]; notify(collPath); },
          async get(){ const d = store[collPath][docId]; return { id:docId, exists: !!d, data:()=>d }; },
          onSnapshot(next){ next({ id:docId, exists: !!store[collPath][docId], data:()=>store[collPath][docId] }); return ()=>{}; },
          collection(sub){ return collection(collPath + '/' + docId + '/' + sub); },
        };
      },
      async add(data){ const ref = api.doc(); await ref.set(data); return ref; },
      _filters: [],
      where(field, op, value){ const c = Object.assign(Object.create(api), {_filters:[...api._filters, {field,op,value}]}); return c; },
      orderBy(){ return this; },
      limit(){ return this; },
      async get(){
        let docs = Object.entries(store[collPath]||{}).map(([id,data])=>({id, exists:true, data:()=>data}));
        (this._filters||[]).forEach(f=>{
          docs = docs.filter(d=>{
            const v = d.data()[f.field];
            if(f.op==='==') return v===f.value;
            return true;
          });
        });
        return { docs, size:docs.length, empty:docs.length===0, docChanges:()=>[] };
      },
      onSnapshot(next, err){
        listeners[collPath] = listeners[collPath] || [];
        listeners[collPath].push(next);
        notify(collPath);
        return ()=>{ listeners[collPath] = listeners[collPath].filter(f=>f!==next); };
      },
    };
    return api;
  }

  return { doc(p){ const parts=p.split('/'); const id=parts.pop(); return collection(parts.join('/')).doc(id); }, collection, __store: store };
}

function setValue(win, el, value){
  const proto = el.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  setter.call(el, value);
  el.dispatchEvent(new win.Event('input', { bubbles: true }));
}
function check(win, el){ el.checked = true; el.dispatchEvent(new win.Event('change', { bubbles: true })); }
function wait(ms){ return new Promise(r=>setTimeout(r, ms)); }
function clickNext(doc){ doc.querySelector('.form-nav .btn-primary').click(); }
function clickRadio(win, doc, name, value){ check(win, doc.querySelector(`input[name="${name}"][value="${value}"]`)); }
function clickCheckbox(win, doc, value){
  const boxes = Array.from(doc.querySelectorAll('input[type="checkbox"]'));
  check(win, boxes.find(b=>b.value===value));
}

let passCount=0, failCount=0;
function assertTrue(cond, label){ if(cond){ console.log('  ✅', label); passCount++; } else { console.log('  ❌', label); failCount++; } }

async function run(){
  console.log('=== SIMULACIÓN CON PERSISTENCIA (mock de la capacidad db real) ===\n');

  const mockDb = makeMockDb();
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.com/',
    beforeParse(win){
      win.claude = { use: async (name) => name === 'db' ? mockDb : null };
    },
  });
  const { window: win } = dom;
  const doc = win.document;

  await wait(120); // deja correr initCapabilities() + subscribeDiagnostics()

  // Completar el formulario (caso "Inventario", esperado: alto potencial)
  win.startForm(); await wait(10);
  setValue(win, doc.querySelector('textarea.f-input'), 'Recibimos reportes de ventas del sistema, actualizamos el inventario, validamos existencias y registramos alertas de stock bajo.');
  clickNext(doc);
  clickRadio(win, doc, 'frequency', 'daily'); clickNext(doc);
  setValue(win, doc.querySelector('input.f-input'), '800'); clickNext(doc);
  setValue(win, doc.querySelector('input.f-input'), '3'); clickNext(doc);
  clickRadio(win, doc, 'structure', 'always'); clickNext(doc);
  clickRadio(win, doc, 'exceptions', 'almost_never'); clickNext(doc);
  clickCheckbox(win, doc, 'erp'); clickCheckbox(win, doc, 'database'); clickCheckbox(win, doc, 'api');
  clickRadio(win, doc, 'integration', 'api_available'); clickNext(doc);
  clickRadio(win, doc, 'humanIntervention', '<25'); clickRadio(win, doc, 'people', 'one'); clickNext(doc);
  clickRadio(win, doc, 'risk', 'low'); clickRadio(win, doc, 'sensitivity', 'no'); clickRadio(win, doc, 'complexity', 'low'); clickNext(doc);
  const inputs = doc.querySelectorAll('.form-card input.f-input');
  setValue(win, inputs[0], 'Carlos Ruiz'); setValue(win, inputs[1], 'Distribuidora Andina');
  setValue(win, inputs[2], 'carlos@distandina.com'); setValue(win, inputs[3], '3001234567');
  doc.querySelector('.form-nav .btn-primary').click();
  await wait(200);

  assertTrue(doc.querySelector('.badge').classList.contains('badge-high'), 'Caso "Inventario" → ALTO POTENCIAL en pantalla');

  const stored = mockDb.__store['diagnostics'] || {};
  const ids = Object.keys(stored);
  assertTrue(ids.length === 1, 'El diagnóstico se persistió exactamente una vez en la colección "diagnostics"');
  const record = stored[ids[0]];
  assertTrue(record.consent === false, 'Se guarda con consent:false ANTES de pedir el lead (sección 22: el diagnóstico no depende del consentimiento comercial)');
  assertTrue(record.status === 'Nuevo', 'El estado inicial es "Nuevo"');
  assertTrue(record.technical_potential === 'high', 'El campo persistido technical_potential coincide con lo mostrado en pantalla');
  assertTrue(record.engine_version === undefined && record.result && record.result.engine_version === 'KIRMA-V1', 'El resultado completo del motor (incluida su versión) queda embebido en el documento persistido');

  // --- Consentimiento → lead ---
  check(win, doc.querySelector('#consent-chk'));
  doc.querySelector('.cta-panel .btn-primary').click();
  await wait(150);
  const recordAfterConsent = mockDb.__store['diagnostics'][ids[0]];
  assertTrue(recordAfterConsent.consent === true, 'Tras marcar el consentimiento y enviar, el mismo documento pasa a consent:true (no se crea un documento nuevo)');
  const activity1 = Object.values(mockDb.__store['diagnostic_activity']||{});
  assertTrue(activity1.some(a=>a.diagnostic_id===ids[0] && a.activity_type==='lead_created'), 'Se registró una entrada de actividad "lead_created" ligada al diagnóstico correcto');

  // --- Dashboard ---
  win.setPortal('team'); await wait(50);
  assertTrue(!!doc.querySelector('.dash-shell'), 'El dashboard renderiza');
  assertTrue(!doc.querySelector('.dash-shell .alert'), 'Con db disponible, el dashboard YA NO muestra el aviso de "almacenamiento no disponible"');
  const kpiNums = Array.from(doc.querySelectorAll('.kpi-strip .kpi-num')).map(n=>n.textContent.trim());
  console.log('  → KPIs del dashboard:', kpiNums);
  assertTrue(kpiNums[0] === '1', 'KPI "Diagnósticos" = 1 (coincide con lo persistido)');
  assertTrue(kpiNums[1] === '1', 'KPI "Alto potencial" = 1');
  assertTrue(kpiNums[4] === '1', 'KPI "Leads" = 1 (el consentimiento se reflejó en el conteo)');

  const rows = doc.querySelectorAll('.dtable tbody tr');
  assertTrue(rows.length === 1, 'La tabla muestra exactamente el diagnóstico creado');
  assertTrue(rows[0].textContent.includes('Distribuidora Andina'), 'La fila muestra la empresa correcta');

  // --- Filtro que no debe coincidir ---
  doc.querySelector('#f-veredicto').value = 'low';
  doc.querySelector('#f-veredicto').dispatchEvent(new win.Event('change', {bubbles:true}));
  await wait(20);
  assertTrue(!!doc.querySelector('.empty-state'), 'Al filtrar por un veredicto que no aplica, se muestra el estado vacío (no una tabla con datos falsos)');
  doc.querySelector('#f-veredicto').value = '';
  doc.querySelector('#f-veredicto').dispatchEvent(new win.Event('change', {bubbles:true}));
  await wait(20);

  // --- Abrir detalle y cambiar estado ---
  doc.querySelector('.dtable tbody tr').click();
  await wait(80);
  const modal = doc.querySelector('.modal');
  assertTrue(!!modal, 'El modal de detalle se abre al hacer clic en la fila');
  assertTrue(modal.textContent.includes('Distribuidora Andina'), 'El detalle muestra los datos del diagnóstico correcto');

  const select = doc.querySelector('#status-select');
  select.value = 'Contactado';
  select.dispatchEvent(new win.Event('change', {bubbles:true}));
  setValue(win, doc.querySelector('#status-note'), 'Llamada inicial realizada, cliente interesado.');
  doc.querySelector('#status-save').click();
  await wait(150);

  const recordAfterStatus = mockDb.__store['diagnostics'][ids[0]];
  assertTrue(recordAfterStatus.status === 'Contactado', 'El estado del diagnóstico cambió a "Contactado" en persistencia real');

  const activity2 = Object.values(mockDb.__store['diagnostic_activity']||{});
  const statusChange = activity2.find(a=>a.activity_type==='status_changed');
  assertTrue(!!statusChange, 'Se registró una entrada de actividad "status_changed"');
  assertTrue(statusChange && statusChange.from_status==='Nuevo' && statusChange.to_status==='Contactado', 'El historial guarda correctamente el estado anterior y el nuevo (sección 29)');
  assertTrue(statusChange && statusChange.note.includes('Llamada inicial'), 'La nota del cambio de estado se guardó tal cual se escribió');

  const pillsAfter = doc.querySelectorAll('.status-pill');
  assertTrue(Array.from(pillsAfter).some(p=>p.textContent.trim()==='Contactado'), 'La tabla del dashboard refleja el nuevo estado sin recargar la página (onSnapshot en vivo)');

  console.log('\n=== RESUMEN ===');
  console.log(`${passCount} verificaciones pasaron, ${failCount} fallaron`);
  process.exit(failCount>0?1:0);
}

run().catch(e=>{ console.error('ERROR EN LA SIMULACIÓN:', e.stack||e); process.exit(1); });
