const { JSDOM } = require('jsdom');
const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, '..', 'app.html'), 'utf8');

function setValue(win, el, value){
  const proto = el.tagName === 'TEXTAREA' ? win.HTMLTextAreaElement.prototype : win.HTMLInputElement.prototype;
  const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
  setter.call(el, value);
  el.dispatchEvent(new win.Event('input', { bubbles: true }));
}
function check(win, el){
  el.checked = true;
  el.dispatchEvent(new win.Event('change', { bubbles: true }));
}
function wait(ms){ return new Promise(r=>setTimeout(r, ms)); }

async function run(){
  console.log('=== SIMULACIÓN END-TO-END SOBRE app.html (el archivo publicado, no una copia) ===\n');

  const dom = new JSDOM(html, { runScripts: 'dangerously', pretendToBeVisual: true, url: 'https://example.com/' });
  const { window: win } = dom;
  const doc = win.document;

  await wait(80); // deja correr initCapabilities() (sin window.claude -> capsReady, sin db/sample)

  // ---------------------------------------------------------------------
  // 1) LANDING
  // ---------------------------------------------------------------------
  let heroTitle = doc.querySelector('.hero-title');
  assertTrue(!!heroTitle, 'Landing renderiza el hero');
  assertTrue(heroTitle.textContent.includes('automatizarse'), 'Hero contiene el mensaje principal');

  const ctaBtn = doc.querySelector('.hero-cta-row .btn-primary');
  assertTrue(!!ctaBtn, 'CTA "Analizar mi proceso" existe');
  ctaBtn.click();

  // ---------------------------------------------------------------------
  // 2) FORMULARIO — 10 pasos, caso "Facturas" (equivalente al caso A del motor)
  // ---------------------------------------------------------------------
  assertTrue(!!doc.querySelector('.form-shell'), 'Navegó a la vista de formulario');
  assertTrue(doc.querySelectorAll('.progress-tick').length === 10, 'La barra de progreso tiene 10 pasos');

  // Paso 1: descripción
  let ta = doc.querySelector('textarea.f-input');
  setValue(win, ta, 'Recibimos facturas por correo, descargamos los PDF, extraemos datos, validamos, registramos en Excel, cargamos al sistema y enviamos confirmación.');
  clickNext(doc);

  // Paso 2: frecuencia
  assertStepQuestion(doc, '¿Con qué frecuencia ocurre?');
  clickRadio(win, doc, 'frequency', 'daily');
  clickNext(doc);

  // Paso 3: volumen
  assertStepQuestion(doc, '¿Cuántas veces se realiza al mes?');
  setValue(win, doc.querySelector('input.f-input'), '450');
  clickNext(doc);

  // Paso 4: tiempo
  assertStepQuestion(doc, '¿Cuánto tiempo toma cada vez?');
  setValue(win, doc.querySelector('input.f-input'), '8');
  clickNext(doc);

  // Paso 5: estructura
  assertStepQuestion(doc, '¿Normalmente sabes exactamente qué hacer?');
  clickRadio(win, doc, 'structure', 'mostly');
  clickNext(doc);

  // Paso 6: excepciones
  assertStepQuestion(doc, '¿Qué ocurre cuando aparece un caso diferente?');
  clickRadio(win, doc, 'exceptions', 'sometimes');
  clickNext(doc);

  // Paso 7: herramientas + integración
  assertStepQuestion(doc, '¿Con qué información y herramientas trabajas?');
  clickCheckbox(win, doc, 'email');
  clickCheckbox(win, doc, 'pdf');
  clickCheckbox(win, doc, 'excel');
  clickCheckbox(win, doc, 'erp');
  clickRadio(win, doc, 'integration', 'api_available');
  clickNext(doc);

  // Paso 8: intervención humana + personas
  assertStepQuestion(doc, '¿Cuánto del proceso requiere intervención humana?');
  clickRadio(win, doc, 'humanIntervention', '25-50');
  clickRadio(win, doc, 'people', 'several');
  clickNext(doc);

  // Paso 9: riesgo + sensibilidad + complejidad
  assertStepQuestion(doc, '¿Qué tan grave sería equivocarse?');
  clickRadio(win, doc, 'risk', 'low');
  clickRadio(win, doc, 'sensitivity', 'no');
  clickRadio(win, doc, 'complexity', 'medium');
  clickNext(doc);

  // Paso 10: contacto
  assertStepQuestion(doc, 'Ya casi terminamos');
  const inputs = doc.querySelectorAll('.form-card input.f-input');
  setValue(win, inputs[0], 'Laura Gómez');
  setValue(win, inputs[1], 'Acme Import S.A.S.');
  setValue(win, inputs[2], 'laura@acmeimport.com');
  setValue(win, inputs[3], '+57 300 000 0000');

  const finishBtn = doc.querySelector('.form-nav .btn-primary');
  assertTrue(finishBtn.textContent.trim() === 'Ver mi diagnóstico', 'El último botón dice "Ver mi diagnóstico"');
  assertTrue(!finishBtn.disabled, 'El botón final está habilitado (todas las respuestas requeridas están completas)');
  finishBtn.click();

  await wait(150); // runDiagnosis() es async (intenta IA -> null -> motor determinista)

  // ---------------------------------------------------------------------
  // 3) RESULTADO
  // ---------------------------------------------------------------------
  const badge = doc.querySelector('.badge');
  assertTrue(!!badge, 'La vista de resultado renderiza el veredicto');
  const veredicto = badge.textContent.trim();
  console.log('  → Veredicto obtenido en pantalla:', JSON.stringify(veredicto));
  assertTrue(badge.classList.contains('badge-high'), 'El caso "Facturas" da ALTO POTENCIAL en la UI real (igual que el test A del motor)');

  const kpiNums = Array.from(doc.querySelectorAll('.kpi-num')).map(n=>n.textContent.trim());
  console.log('  → KPIs mostrados:', kpiNums);
  assertTrue(kpiNums[0] === '450', 'KPI operaciones/mes = 450 (coincide con lo capturado en el formulario)');
  assertTrue(kpiNums[1] === '8', 'KPI minutos/operación = 8');
  assertTrue(kpiNums[2] === '60', 'KPI horas estimadas = 450×8/60 = 60 (cálculo verificado en pantalla, no solo en el motor)');

  const stageCards = doc.querySelectorAll('.stage-card');
  assertTrue(stageCards.length > 0, 'Se detectaron y renderizaron etapas del proceso (heurística sin IA, ya que window.claude no existe en esta simulación)');
  console.log('  → Etapas detectadas:', Array.from(stageCards).map(c=>c.querySelector('.stage-name').textContent.trim()));

  const metaLine = doc.querySelector('.result-meta').textContent;
  assertTrue(metaLine.includes('SOLO REGLAS DETERMINISTAS'), 'La UI deja explícito que este resultado corrió sin IA (fallback correcto, sección 27)');

  const alerts = doc.querySelectorAll('.alert-danger');
  assertTrue(alerts.length === 0, 'Sin contradicciones para este caso (esperado, coincide con el motor)');

  const chips = doc.querySelectorAll('.chip');
  console.log('  → Tecnologías recomendadas:', Array.from(chips).map(c=>c.textContent.trim()));
  assertTrue(chips.length > 0, 'Se muestran recomendaciones tecnológicas');

  // ---------------------------------------------------------------------
  // 4) CONSENTIMIENTO → LEAD (sin backend real, valida el guardado de errores/mensajes)
  // ---------------------------------------------------------------------
  const consentBtn = doc.querySelector('.cta-panel .btn-primary');
  consentBtn.click(); // sin marcar el checkbox de consentimiento todavía
  await wait(20);
  const errText = doc.querySelector('.cta-panel .error-text');
  assertTrue(errText && errText.style.display !== 'none', 'Si se intenta enviar sin marcar el consentimiento, la UI bloquea el envío y muestra el error (sección 22: el lead exige consentimiento explícito)');

  const consentChk = doc.querySelector('#consent-chk');
  check(win, consentChk);
  consentBtn.click();
  await wait(80);
  assertTrue(consentBtn.textContent.includes('✓') || consentBtn.textContent.includes('enviada'), 'Con consentimiento marcado, el botón confirma el envío en la UI (persistencia real de "lead" se omite: no hay capacidad db en esta simulación headless, esperado)');

  // ---------------------------------------------------------------------
  // 5) CASO DE CONTRADICCIÓN, corrido también contra la UI real
  // ---------------------------------------------------------------------
  console.log('\n--- Segunda corrida: caso con contradicción (volumen alto + tiempo cero) ---');
  win.startForm();
  await wait(20);
  ta = doc.querySelector('textarea.f-input');
  setValue(win, ta, 'Procesamos pedidos todos los días de forma manual.');
  clickNext(doc);
  clickRadio(win, doc, 'frequency', 'daily'); clickNext(doc);
  setValue(win, doc.querySelector('input.f-input'), '500'); clickNext(doc);
  setValue(win, doc.querySelector('input.f-input'), '0'); clickNext(doc);
  clickRadio(win, doc, 'structure', 'mostly'); clickNext(doc);
  clickRadio(win, doc, 'exceptions', 'sometimes'); clickNext(doc);
  clickCheckbox(win, doc, 'erp'); clickRadio(win, doc, 'integration', 'api_available'); clickNext(doc);
  clickRadio(win, doc, 'humanIntervention', '25-50'); clickRadio(win, doc, 'people', 'one'); clickNext(doc);
  clickRadio(win, doc, 'risk', 'low'); clickRadio(win, doc, 'sensitivity', 'no'); clickRadio(win, doc, 'complexity', 'low'); clickNext(doc);
  doc.querySelector('.form-nav .btn-primary').click();
  await wait(150);

  const badge2 = doc.querySelector('.badge');
  console.log('  → Veredicto obtenido en pantalla:', badge2.textContent.trim());
  assertTrue(badge2.classList.contains('badge-technical'), 'La contradicción fuerza "REQUIERE EVALUACIÓN TÉCNICA" también en la UI real');
  const dangerAlerts = doc.querySelectorAll('.alert-danger');
  assertTrue(dangerAlerts.length > 0, 'La alerta de contradicción se renderiza visiblemente en pantalla');
  console.log('  → Alerta mostrada:', dangerAlerts[0].textContent.trim());

  // ---------------------------------------------------------------------
  // 6) VALIDACIÓN DE FORMULARIO: no se puede avanzar sin responder
  // ---------------------------------------------------------------------
  console.log('\n--- Verificación de validación de pasos obligatorios ---');
  win.startForm();
  await wait(20);
  const firstNext = doc.querySelector('.form-nav .btn-primary');
  assertTrue(firstNext.disabled === true, 'El botón "Continuar" está deshabilitado si la descripción tiene menos de 15 caracteres (sin responder nada)');

  // ---------------------------------------------------------------------
  // 7) DASHBOARD (equipo KIRMA) — vista sin capacidad db (esperado: aviso claro, no crash)
  // ---------------------------------------------------------------------
  console.log('\n--- Verificación del panel de equipo sin backend disponible ---');
  win.setPortal('team');
  await wait(20);
  assertTrue(!!doc.querySelector('.dash-shell'), 'El dashboard renderiza sin lanzar excepciones');
  const dashAlert = doc.querySelector('.dash-shell .alert');
  assertTrue(dashAlert && dashAlert.textContent.includes('almacenamiento compartido no está disponible'), 'Sin capacidad db (como en esta simulación headless), el dashboard avisa con claridad en vez de fallar en silencio o mostrar datos falsos');

  console.log('\n=== RESUMEN ===');
  console.log(`${passCount} verificaciones pasaron, ${failCount} fallaron`);
  process.exit(failCount > 0 ? 1 : 0);
}

let passCount = 0, failCount = 0;
function assertTrue(cond, label){
  if(cond){ console.log('  ✅', label); passCount++; }
  else { console.log('  ❌', label); failCount++; }
}
function assertStepQuestion(doc, text){
  const q = doc.querySelector('.form-q');
  assertTrue(q && q.textContent.trim() === text, `Paso muestra la pregunta: "${text}"`);
}
function clickNext(doc){
  const btn = doc.querySelector('.form-nav .btn-primary');
  btn.click();
}
function clickRadio(win, doc, name, value){
  const input = doc.querySelector(`input[name="${name}"][value="${value}"]`);
  if(!input) throw new Error(`No se encontró radio ${name}=${value}`);
  check(win, input);
}
function clickCheckbox(win, doc, value){
  const boxes = doc.querySelectorAll('input[type="checkbox"]');
  const input = Array.from(boxes).find(b=>b.value===value);
  if(!input) throw new Error(`No se encontró checkbox ${value}`);
  check(win, input);
}

run().catch(err=>{ console.error('ERROR EN LA SIMULACIÓN:', err); process.exit(1); });
