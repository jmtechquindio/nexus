# TESTING.md

## Cómo correr las pruebas del motor

```bash
node tests/engine.test.js
```

Resultado actual: **13/13 pasaron**.

## Casos obligatorios (sección 32) y su resultado

| Caso | Escenario | Esperado | Obtenido |
|---|---|---|---|
| A | Facturas por correo, PDF, Excel, ERP, riesgo bajo | Alto potencial | ✅ `high` |
| B | Atención por WhatsApp, poco estructurado, excepciones frecuentes | Parcial o evaluación técnica | ✅ `partial` |
| C | Cartera vencida, negociación caso a caso, riesgo alto | Evaluación técnica | ✅ `technical` |
| D | Actualización de inventario, reglas claras, API disponible | Alto potencial | ✅ `high` |
| E | Aprobación de créditos grandes, riesgo crítico | Evaluación técnica | ✅ `technical` |
| F | Campaña creativa ocasional, subjetiva | Bajo potencial actual | ✅ `low` |
| G | 3 variantes de contradicción (volumen/tiempo, estructura/dependencia, riesgo crítico/sin supervisión) | Evaluación técnica + confianza baja | ✅ `technical` + `confidence: low` en las 3 |

## Reglas transversales probadas

- `internal_score` siempre es un número entre 0 y 1 — nunca se calcula ni
  se expone como porcentaje de éxito.
- Información insuficiente (muchos campos `unknown`) fuerza
  `technical` + `confidence: low`, nunca un veredicto optimista por
  omisión (sección 11).
- Cálculo de horas: `volumen × minutos / 60`, exacto.
- El motor nunca produce el texto "no se puede automatizar", ni siquiera
  en el caso de bajo potencial.

## Lo que falta para una cobertura de calidad tipo sección 33–34

Definido pero no ejecutado en este entregable (requiere backend real):

- **Trazabilidad completa**: entrada → diagnóstico → persistencia →
  dashboard → cambio de estado → historial → consentimiento → lead →
  diagnóstico sin lead cuando no hay consentimiento. La lógica ya existe
  en `app.html` (`runDiagnosis`, `createLead`, `changeStatus`) y se probó
  manualmente durante la construcción, pero no hay pruebas de integración
  automatizadas contra una base de datos real en este entregable.
- **Calidad del motor vs. evaluación humana** (sección 34): requiere un
  conjunto de procesos reales de KIRMA-SOFT evaluados por un humano
  experto para comparar contra el motor y registrar coincidencia/
  discrepancia/razón — no existe ese conjunto de referencia en este
  entregable, así que no se puede fabricar sin inventar datos.

## Simulación end-to-end contra el `app.html` real (no una copia)

Además de las pruebas del motor aislado, `/tests/simulate-ui.js` y
`/tests/simulate-persistence.js` cargan el propio `app.html` dentro de un
DOM headless (jsdom) y lo operan como lo haría una persona: clics reales,
eventos `input`/`change` reales, sin acceder al estado interno por atajos.
`simulate-persistence.js` además implementa un mock del contrato real de
la capacidad `db` (mismos métodos `collection/doc/set/update/add/where/
onSnapshot`) para ejercitar de verdad diagnóstico → lead → dashboard →
cambio de estado → historial.

```bash
npm install jsdom   # una vez
node tests/simulate-ui.js
node tests/simulate-persistence.js
```

Resultado actual: **32/32** y **23/23** verificaciones en verde.

### Bugs reales que esta simulación encontró y se corrigieron

Correr el motor por separado nunca los habría detectado — solo aparecen
al ejercitar el HTML/JS real tal como lo ve una persona:

1. **Navegación principal inerte.** El logo, el interruptor de portal y
   los dos botones "Analizar mi proceso" usaban `onclick="..."` inline
   dentro de HTML construido con `<template>` + `innerHTML`. Por
   especificación, el contenido de un `<template>` no tiene contexto de
   navegación (`window`) en el momento en que el atributo se parsea, así
   que ese manejador de evento **nunca se compila — ni siquiera después
   de mover el nodo al documento real.** Esto no era un capricho de
   jsdom: pasa igual en Chrome/Firefox reales. Nadie podía entrar al
   formulario ni al panel desde el landing. Se corrigió reemplazando
   todo `onclick` inline por `addEventListener` explícito después de
   crear cada elemento.
2. **Botón "Continuar" atascado en deshabilitado.** En los pasos de
   texto/número (descripción, volumen, minutos), el campo actualizaba
   `S.answers` pero nunca volvía a evaluar si el paso ya era válido, así
   que el botón quedaba deshabilitado para siempre aunque la persona
   completara el campo. Se corrigió con `refreshNextButtonState()`, una
   actualización dirigida al botón (sin re-renderizar todo el paso, para
   no perder el foco del cursor mientras se escribe).
3. **Scroll a la parte superior en cada clic.** `render()` hacía
   `window.scrollTo(top:0)` incondicionalmente, incluso al marcar una
   sola opción dentro del mismo paso — la página "saltaba" hacia arriba
   con cada selección. Se movió el scroll a los puntos reales de
   navegación (cambiar de vista o de paso), no a cada re-render.

## Cómo extender la suite

Cada nuevo caso de prueba debe:

1. Llamar a `runKirmaEngine(input)` con un input completo y realista.
2. Afirmar el `technical_potential` esperado y, cuando aplique,
   `confidence` y/o `contradictions`.
3. Nunca ajustar las reglas del motor solo para hacer pasar una prueba
   sin justificar el cambio en `ENGINE.md` (sección 34: "no modificar las
   reglas simplemente para aumentar artificialmente la tasa de
   coincidencia").
